package Control.Gestores;

import Control.DAO.MateriaDAO;
import Modelo.MateriaVO;
import Vista.VistaMateria;
import Vista.VistaTabla;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class GestorMateria implements ActionListener {

    private ArrayList<MateriaVO> listaMaterias;
    private MateriaDAO miMateriaDAO = new MateriaDAO();
    private MateriaVO objMateria = new MateriaVO();
    private VistaMateria vista;
    private VistaTabla vistaTabla = new VistaTabla();
    private GestorBienvenida gestor;

    public GestorMateria() {
        this.vista = new VistaMateria();
        this.vista.btnVolver.addActionListener(this);
        this.vista.btnSeleccionar.addActionListener(this);
        this.vista.btnCrear.addActionListener(this);
        this.vista.btnLista.addActionListener(this);
        this.vista.btnEliminar.addActionListener(this);
        this.vista.btnModificar.addActionListener(this);
    }

    public void iniciar() {
        this.vista.setLocationRelativeTo(null);
        this.vista.setResizable(false);
        this.vista.setVisible(true);
    }

    public void iniciar(GestorBienvenida vuelta) {
        gestor = vuelta;
        this.vista.setLocationRelativeTo(null);
        llenarComboboxMateria();
        this.vista.setResizable(false);
        this.vista.setVisible(true);
    }

    private void llenarComboboxMateria() {
        vista.comboxMaterias.removeAllItems();
        vista.comboxMaterias.addItem("Seleccionar");
        listaMaterias = miMateriaDAO.listaDeMaterias();
        for (int i = 0; i < listaMaterias.size(); i++) {
            vista.comboxMaterias.addItem(listaMaterias.get(i).getNombre());
        }
    }

    // Método para verificar si hay campos de texto vacíos
    private boolean camposTextoVacios() {
        return this.vista.txtId.getText().isEmpty()
                || this.vista.txtNombre.getText().isEmpty()
                || this.vista.txtDescripcion.getText().isEmpty();
    }

    // Método para verificar si un nombre ya existe en el ComboBox
    private boolean nombreExistente(String nombre) {
        int itemCount = this.vista.comboxMaterias.getItemCount();
        for (int i = 0; i < itemCount; i++) {
            if (nombre.equals(this.vista.comboxMaterias.getItemAt(i))) {
                return true; // El nombre ya existe en el ComboBox
            }
        }
        return false; // El nombre no existe en el ComboBox
    }

    private boolean idExistente(int materiaId) {
        listaMaterias = miMateriaDAO.listaDeMaterias();
        int itemCount = listaMaterias.size();
        for (int i = 0; i < itemCount; i++) {
            objMateria = listaMaterias.get(i);
            int tempId = objMateria.getMateriaId();
            if (materiaId == tempId) {
                //Ya existe el id en la db
                return true;
            }
        }
        //No existe el id en la DB
        return false;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        //Boton volver
        if (e.getSource() == vista.btnVolver) {
            vista.setVisible(false);
            gestor.iniciar();
        }

        //Funcion para desplegar el usuario seleccionado en los textfield
        if (e.getSource() == vista.btnSeleccionar) {
            this.vista.txtId.setEditable(false);
            listaMaterias = miMateriaDAO.listaDeMaterias();
            String strNombre = (String) vista.comboxMaterias.getSelectedItem();
            for (MateriaVO objMateria : listaMaterias) {
                if (strNombre.equals(objMateria.getNombre())) {
                    this.vista.txtId.setText(Integer.toString(objMateria.getMateriaId()));
                    this.vista.txtNombre.setText(objMateria.getNombre());
                    this.vista.txtDescripcion.setText(objMateria.getDescripcion());
                }
            }
        }

        // Agregar Materia
        if (e.getSource() == this.vista.btnCrear) {
            vista.txtId.setEditable(true);
            listaMaterias = miMateriaDAO.listaDeMaterias();
            int id = Integer.parseInt(this.vista.txtId.getText());
            String nombre = this.vista.txtNombre.getText();
            String descripcion = this.vista.txtDescripcion.getText();
            if (camposTextoVacios()) {
                this.vista.error("Todos los campos deben estar llenos");
            } else {
                // Verificar si el nombre ya está en el ComboBox
                if (!nombreExistente(nombre)) {
                    // El nombre no existe en el ComboBox, proceder con la inserción
                    if (!idExistente(id)) {
                        this.objMateria.setMateriaId(id);
                        this.objMateria.setNombre(nombre);
                        this.objMateria.setDescripcion(descripcion);
                        this.vista.msg("Materia agregada con exito");
                        miMateriaDAO.insertarDatos(objMateria);
                        llenarComboboxMateria();
                        vista.limpiar();
                    } else {
                        this.vista.error("Ya existe una materia con id: " + id);
                    }
                } else {
                    this.vista.error("Ya existe una materia con nombre: " + nombre);
                }
            }
        }

        if (e.getSource() == this.vista.btnModificar) {
            listaMaterias = miMateriaDAO.listaDeMaterias();
            String nombre = (String) this.vista.comboxMaterias.getSelectedItem();
            if (vista.txtNombre.getText().isEmpty() || vista.txtDescripcion.getText().isEmpty()) {
                vista.error("No se permiten espacios vacios");
            } else {
                for (MateriaVO objMateria : miMateriaDAO.listaDeMaterias()) {
                    if (objMateria.getNombre().equals(nombre)) {
                        objMateria.setNombre(this.vista.txtNombre.getText());
                        objMateria.setDescripcion(this.vista.txtDescripcion.getText());
                        this.miMateriaDAO.actualizarDatos(objMateria);
                        this.vista.msg("Materia Modificada");
                        this.vista.limpiar();
                        llenarComboboxMateria();
                        break;  // Se detiene después de encontrar la primera coincidencia
                    }
                }
            }
        }

        // Eliminar proveedor
        if (e.getSource() == this.vista.btnEliminar) {
            vista.txtId.setEditable(true);
            listaMaterias = miMateriaDAO.listaDeMaterias();
            String nombre = (String) this.vista.comboxMaterias.getSelectedItem();
            for (MateriaVO objMateria : miMateriaDAO.listaDeMaterias()) {
                if (objMateria.getNombre().equals(nombre)) {
                    int Id = objMateria.getMateriaId();
                    this.miMateriaDAO.eliminarMateria(Id);
                    this.vista.msg("Materia Eliminada");
                    this.vista.limpiar();
                    llenarComboboxMateria();
                    break;
                }
            }
        }

        if (e.getSource() == this.vista.btnLista) {
            this.vistaTabla.mostrarVentana(this.miMateriaDAO.cargarDatosTabla(), "Materias");
        }
    }
}
