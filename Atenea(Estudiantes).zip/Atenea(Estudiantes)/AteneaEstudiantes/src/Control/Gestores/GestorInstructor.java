package Control.Gestores;

import Control.DAO.InstructorDAO;
import Control.DAO.MateriaDAO;
import Control.DAO.MonitorDAO;
import Modelo.InstructorVO;
import Modelo.MateriaVO;
import Modelo.MonitorVO;
import Vista.VistaInstructor;
import Vista.VistaTabla;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class GestorInstructor implements ActionListener {

    private ArrayList<InstructorVO> listaInstructores;
    private ArrayList<MonitorVO> listaMonitores;
    private ArrayList<MateriaVO> listaMaterias;
    private InstructorDAO miInstructorDAO = new InstructorDAO();
    private MonitorDAO miMonitorDAO = new MonitorDAO();
    private MateriaDAO miMateriaDAO = new MateriaDAO();
    private InstructorVO objInstructor = new InstructorVO();
    private MonitorVO objMonitor = new MonitorVO();
    private MateriaVO objMateria = new MateriaVO();
    private VistaInstructor vista;
    private VistaTabla vistaTabla = new VistaTabla();
    private GestorBienvenida gestor;

    public GestorInstructor() {
        this.vista = new VistaInstructor();
        this.vista.btnVolver.addActionListener(this);
        this.vista.btnSeleccionarInstructor.addActionListener(this);
        this.vista.btnSeleccionarMateria.addActionListener(this);
        this.vista.btnSeleccionarMonitor.addActionListener(this);
        this.vista.btnCrear.addActionListener(this);
        this.vista.btnLista.addActionListener(this);
        this.vista.btnEliminar.addActionListener(this);
        this.vista.btnModificar.addActionListener(this);
    }

    public void iniciar() {
        this.vista.setLocationRelativeTo(null);
        this.vista.setResizable(false);
        this.vista.setVisible(true);
    }

    public void iniciar(GestorBienvenida vuelta) {
        gestor = vuelta;
        this.vista.setLocationRelativeTo(null);
        llenarComboboxInstructor();
        llenarComboboxMonitor();
        llenarComboboxMateria();
        this.vista.setResizable(false);
        this.vista.setVisible(true);
    }

    private void llenarComboboxInstructor() {
        vista.comboxInstructores.removeAllItems();
        vista.comboxInstructores.addItem("Seleccionar");
        listaInstructores = miInstructorDAO.listaDeInstructores();
        for (int i = 0; i < listaInstructores.size(); i++) {
            vista.comboxInstructores.addItem(listaInstructores.get(i).getNombre());
        }
    }

    private void llenarComboboxMonitor() {
        vista.comboxMonitor.removeAllItems();
        vista.comboxMonitor.addItem("Seleccionar");
        listaMonitores = miMonitorDAO.listaDeMonitores();
        for (int i = 0; i < listaMonitores.size(); i++) {
            vista.comboxMonitor.addItem(listaMonitores.get(i).getNombre());
        }
    }

    private void llenarComboboxMateria() {
        vista.comboxMaterias.removeAllItems();
        vista.comboxMaterias.addItem("Seleccionar");
        listaMaterias = miMateriaDAO.listaDeMaterias();
        for (int i = 0; i < listaMaterias.size(); i++) {
            vista.comboxMaterias.addItem(listaMaterias.get(i).getNombre());
        }
    }

    // Método para verificar si hay campos de texto vacíos
    private boolean camposTextoVacios() {
        return this.vista.txtId.getText().isEmpty()
                || this.vista.txtNombre.getText().isEmpty()
                || this.vista.txtDireccion.getText().isEmpty()
                || this.vista.txtFechadeNacimiento.getText().isEmpty()
                || this.vista.txtTelefono.getText().isEmpty()
                || this.vista.txtCorreo.getText().isEmpty();
    }

    // Método para obtener el monitorId basado en el nombre seleccionado en el combobox
    private int getMonitorIdByName(String monitorName) {
        for (MonitorVO monitor : listaMonitores) {
            if (monitor.getNombre().equals(monitorName)) {
                return monitor.getMonitorId();
            }
        }
        return -1; // retornar un valor inválido si no se encuentra
    }

// Método para obtener el materiaId basado en el nombre seleccionado en el combobox
    private int getMateriaIdByName(String materiaName) {
        for (MateriaVO materia : listaMaterias) {
            if (materia.getNombre().equals(materiaName)) {
                return materia.getMateriaId();
            }
        }
        return -1; // retornar un valor inválido si no se encuentra
    }

    // Método para verificar si un nombre ya existe en el ComboBox
    private boolean nombreExistente(String nombre) {
        int itemCount = this.vista.comboxInstructores.getItemCount();
        for (int i = 0; i < itemCount; i++) {
            if (nombre.equals(this.vista.comboxInstructores.getItemAt(i))) {
                return true; // El nombre ya existe en el ComboBox
            }
        }
        return false; // El nombre no existe en el ComboBox
    }

    private boolean idExistente(int id) {
        listaInstructores = miInstructorDAO.listaDeInstructores();
        int itemCount = listaInstructores.size();
        for (int i = 0; i < itemCount; i++) {
            objInstructor = listaInstructores.get(i);
            int tempId = objInstructor.getInstructorId();
            if (id == tempId) {
                //Ya existe el id en la db
                return true;
            }
        }
        //No existe el id en la DB
        return false;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        //Volver
        if (e.getSource() == vista.btnVolver) {
            vista.setVisible(false);
            gestor.iniciar();
        }

        //Mostrar instructor
        if (e.getSource() == vista.btnSeleccionarInstructor) {
            this.vista.txtId.setEditable(false);
            listaInstructores = miInstructorDAO.listaDeInstructores();
            String strNombre = (String) vista.comboxInstructores.getSelectedItem();
            for (InstructorVO objInstructor : listaInstructores) {
                if (strNombre.equals(objInstructor.getNombre())) {
                    this.vista.txtId.setText(Integer.toString(objInstructor.getInstructorId()));
                    this.vista.txtNombre.setText(objInstructor.getNombre());
                    this.vista.txtDireccion.setText(objInstructor.getDireccion());
                    this.vista.txtFechadeNacimiento.setText(objInstructor.getFechaNacimiento());
                    this.vista.txtTelefono.setText(objInstructor.getTelefono());
                    this.vista.txtCorreo.setText(objInstructor.getCorreo());
                    this.vista.txtMateria.setText(objInstructor.getNombreMateria());
                    this.vista.txtMonitor.setText(objInstructor.getNombreMonitor());
                }
            }
        }

        // Crear Instructor

        if (e.getSource() == this.vista.btnCrear) {
            vista.txtId.setEditable(true);
            int id = Integer.parseInt(this.vista.txtId.getText());
            String nombre = this.vista.txtNombre.getText();
            String direccion = this.vista.txtDireccion.getText();
            String fechadeNacimiento = this.vista.txtFechadeNacimiento.getText();
            String telefono = this.vista.txtTelefono.getText();
            String correo = this.vista.txtCorreo.getText();
            if (camposTextoVacios()) {
                this.vista.error("TODOS LOS CAMPOS DEBEN ESTAR LLENOS");
            } else {
                // Obtener los IDs del monitor y materia seleccionados
                int monitorId = getMonitorIdByName((String) this.vista.comboxMonitor.getSelectedItem());
                int materiaId = getMateriaIdByName((String) this.vista.comboxMaterias.getSelectedItem());

                // Verificar si el nombre ya está en el ComboBox
                if (!nombreExistente(nombre) && !idExistente(id)) {
                    // El nombre no existe en el ComboBox, proceder con la inserción
                    InstructorVO nuevoInstructor = new InstructorVO(id, monitorId, materiaId, nombre, direccion, fechadeNacimiento, telefono, correo);
                    this.miInstructorDAO.insertarDatos(nuevoInstructor);
                    this.vista.msg("El instructor fue agregado con exito");
                    llenarComboboxInstructor();
                    vista.limpiar();
                } else {
                    this.vista.error("Ya existe el Instructor " + nombre + " con ID: " + id);
                }
            }
        }

        //Modifica un instructor
        if (e.getSource() == this.vista.btnModificar) {
            listaInstructores = miInstructorDAO.listaDeInstructores();
            String nombre = (String) this.vista.comboxInstructores.getSelectedItem();
            if (vista.txtNombre.getText().isEmpty() || vista.txtDireccion.getText().isEmpty() || vista.txtCorreo.getText().isEmpty() || vista.txtTelefono.getText().isEmpty()) {
                vista.error("No se permiten espacios en blanco");
            } else {
                for (InstructorVO objInstructor : miInstructorDAO.listaDeInstructores()) {
                    if (objInstructor.getNombre().equals(nombre)) {
                        objInstructor.setNombre(this.vista.txtNombre.getText());
                        objInstructor.setDireccion(this.vista.txtDireccion.getText());
                        objInstructor.setFechaNacimiento(this.vista.txtFechadeNacimiento.getText());
                        objInstructor.setTelefono(this.vista.txtTelefono.getText());
                        objInstructor.setCorreo(this.vista.txtCorreo.getText());
                        this.miInstructorDAO.actualizarDatos(objInstructor);
                        this.vista.msg("El instructor fue modificado con exito");
                        this.vista.limpiar();
                        llenarComboboxInstructor();
                        break;
                    }
                }
            }
        }

        //Modificar Materia
        if (e.getSource() == this.vista.btnSeleccionarMateria) {
            listaInstructores = miInstructorDAO.listaDeInstructores();
            String materia = (String) this.vista.comboxMaterias.getSelectedItem();
            if ("".equals((String) this.vista.comboxInstructores.getSelectedItem())) {
                this.vista.error("Seleccione un instructor primero");
            } else {
                String nombre = (String) this.vista.comboxInstructores.getSelectedItem();
                for (InstructorVO objInstructor : miInstructorDAO.listaDeInstructores()) {
                    if (objInstructor.getNombre().equals(nombre)) {
                        for (MateriaVO objMateria : miMateriaDAO.listaDeMaterias()) {
                            if (objMateria.getNombre().equals(materia)) {
                                int materiaTemp = objMateria.getMateriaId();
                                objInstructor.setMateriaId(materiaTemp);
                                this.miInstructorDAO.actualizarDatos(objInstructor);
                                this.vista.msg("La materia ha sido actualizada");
                            }
                        }
                    }
                }
            }
        }

        //Modificar Monitor
        if (e.getSource() == this.vista.btnSeleccionarMonitor) {
            listaInstructores = miInstructorDAO.listaDeInstructores();
            String monitor = (String) this.vista.comboxMonitor.getSelectedItem();
            if ("".equals((String) this.vista.comboxInstructores.getSelectedItem())) {
                this.vista.error("Seleccione un instructor primero");
            } else {
                String nombre = (String) this.vista.comboxInstructores.getSelectedItem();
                for (InstructorVO objInstructor : miInstructorDAO.listaDeInstructores()) {
                    if (objInstructor.getNombre().equals(nombre)) {
                        for (MonitorVO objMonitor : miMonitorDAO.listaDeMonitores()) {
                            if (objMonitor.getNombre().equals(monitor)) {
                                int monitorTemp = objMonitor.getMonitorId();
                                objInstructor.setMonitorId(monitorTemp);
                                this.miInstructorDAO.actualizarDatos(objInstructor);
                                this.vista.msg("La materia ha sido actualizada");
                            }
                        }
                    }
                }
            }
        }

        //Eliminar
        if (e.getSource() == this.vista.btnEliminar) {
            vista.txtId.setEditable(true);
            listaInstructores = miInstructorDAO.listaDeInstructores();
            String nombre = (String) this.vista.comboxInstructores.getSelectedItem();
            for (InstructorVO objInstructor : miInstructorDAO.listaDeInstructores()) {
                if (objInstructor.getNombre().equals(nombre)) {
                    int Id = objInstructor.getInstructorId();
                    this.miInstructorDAO.eliminarInstructor(Id);
                    this.vista.msg("Instructor Eliminado");
                    this.vista.limpiar();
                    llenarComboboxInstructor();
                    break;
                }
            }
        }

        if (e.getSource() == this.vista.btnLista) {
            this.vistaTabla.mostrarVentana(this.miInstructorDAO.cargarDatosTabla(), "Instructores");
        }
    }
}
