package Control.Gestores;

import Control.DAO.EstudianteDAO;
import Control.DAO.InstructorDAO;
import Control.DAO.MateriaDAO;
import Modelo.EstudianteVO;
import Modelo.InstructorVO;
import Modelo.MateriaVO;
import Modelo.MonitorVO;
import Vista.VistaEstudiante;
import Vista.VistaTabla;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class GestorEstudiante implements ActionListener {

    private ArrayList<EstudianteVO> listaEstudiantes;
    private ArrayList<MonitorVO> listaMonitores;
    private ArrayList<InstructorVO> listaInstructores;
    private ArrayList<MateriaVO> listaMaterias;
    private EstudianteDAO miEstudianteDAO = new EstudianteDAO();
    private EstudianteVO objEstudiante = new EstudianteVO();
    private InstructorDAO miInstructorDAO = new InstructorDAO();
    private InstructorVO objInstructor = new InstructorVO();
    private MateriaDAO miMateriaDAO = new MateriaDAO();
    private MateriaVO objMateria = new MateriaVO();
    private VistaEstudiante vista;
    private VistaTabla vistaTabla = new VistaTabla();
    private GestorBienvenida gestor;

    public GestorEstudiante() {
        this.vista = new VistaEstudiante();
        this.vista.btnVolver.addActionListener(this);
        this.vista.btnSeleccionarEstudiante.addActionListener(this);
        this.vista.btnSeleccionarInstructor.addActionListener(this);
        this.vista.btnCrear.addActionListener(this);
        this.vista.btnLista.addActionListener(this);
        this.vista.btnEliminar.addActionListener(this);
        this.vista.btnModificar.addActionListener(this);
    }

    public void iniciar() {
        this.vista.setLocationRelativeTo(null);
        this.vista.setResizable(false);
        this.vista.setVisible(true);
    }

    public void iniciar(GestorBienvenida vuelta) {
        gestor = vuelta;
        this.vista.setLocationRelativeTo(null);
        llenarComboboxEstudiante();
        llenarComboboxEstudiante();
        llenarComboboxInstructor();
        this.vista.setResizable(false);
        this.vista.setVisible(true);
    }

    private void llenarComboboxEstudiante() {
        vista.comboxEstudiantes.removeAllItems();
        vista.comboxEstudiantes.addItem("Seleccionar");
        listaEstudiantes = miEstudianteDAO.listaDeEstudiantes();
        for (int i = 0; i < listaEstudiantes.size(); i++) {
            vista.comboxEstudiantes.addItem(listaEstudiantes.get(i).getNombre());
        }
    }

    private void llenarComboboxInstructor() {
        vista.comboxInstructor.removeAllItems();
        vista.comboxInstructor.addItem("Seleccionar");
        listaInstructores = miInstructorDAO.listaDeInstructores();
        for (int i = 0; i < listaInstructores.size(); i++) {
            vista.comboxInstructor.addItem(listaInstructores.get(i).getNombre());
        }
    }

    // Método para verificar si hay campos de texto vacíos
    private boolean camposTextoVacios() {
        return this.vista.txtId.getText().isEmpty()
                || this.vista.txtNombre.getText().isEmpty()
                || this.vista.txtDireccion.getText().isEmpty()
                || this.vista.txtFechadeNacimiento.getText().isEmpty()
                || this.vista.txtTelefono.getText().isEmpty()
                || this.vista.txtCorreo.getText().isEmpty();
    }

    // Método para verificar si un nombre ya existe en el ComboBox
    private boolean nombreExistente(String nombre) {
        int itemCount = this.vista.comboxEstudiantes.getItemCount();
        for (int i = 0; i < itemCount; i++) {
            if (nombre.equals(this.vista.comboxEstudiantes.getItemAt(i))) {
                return true; // El nombre ya existe en el ComboBox
            }
        }
        return false; // El nombre no existe en el ComboBox
    }

    private boolean idExistente(int estudianteId) {
        listaEstudiantes = miEstudianteDAO.listaDeEstudiantes();
        int itemCount = listaEstudiantes.size();
        for (int i = 0; i < itemCount; i++) {
            objEstudiante = listaEstudiantes.get(i);
            int tempId = objEstudiante.getEstudianteId();
            if (estudianteId == tempId) {
                //Ya existe el id en la db
                return true;
            }
        }
        //No existe el id en la DB
        return false;
    }

    // Método para obtener el monitorId basado en el nombre seleccionado en el combobox
    private int obtenerIdInstructor(String nombreInstructor) {
        listaInstructores = miInstructorDAO.listaDeInstructores();
        for (InstructorVO objInstructor : listaInstructores) {
            if (objInstructor.getNombre().equals(nombreInstructor)) {
                return objInstructor.getInstructorId();
            }
        }
        return -1; // retornar un valor inválido si no se encuentra
    }
    
    private InstructorVO obtenerObjInstructor(String nombreInstructor){
        listaInstructores = miInstructorDAO.listaDeInstructores();
        for(int i = 0; i < listaInstructores.size(); i++){
            if (listaInstructores.get(i).getNombre().equals(nombreInstructor)){
                return listaInstructores.get(i);
            } else {
            }
        }
        return null;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        //Volver al menu
        if (e.getSource() == vista.btnVolver) {
            vista.setVisible(false);
            gestor.iniciar();
        }

        //Seleccionar estudiante
        if (e.getSource() == vista.btnSeleccionarEstudiante) {
            this.vista.txtId.setEditable(false);
            listaEstudiantes = miEstudianteDAO.listaDeEstudiantes();
            String strNombre = (String) vista.comboxEstudiantes.getSelectedItem();
            for (EstudianteVO objEstudiante : listaEstudiantes) {
                if (strNombre.equals(objEstudiante.getNombre())) {
                    this.vista.txtId.setText(Integer.toString(objEstudiante.getEstudianteId()));
                    this.vista.txtNombre.setText(objEstudiante.getNombre());
                    this.vista.txtDireccion.setText(objEstudiante.getDireccion());
                    this.vista.txtFechadeNacimiento.setText(objEstudiante.getFechaNacimiento());
                    this.vista.txtTelefono.setText(objEstudiante.getTelefono());
                    this.vista.txtCorreo.setText(objEstudiante.getCorreo());
                    this.vista.txtMateria.setText(objEstudiante.getNombreMateria());
                    this.vista.txtInstructor.setText(objEstudiante.getNombreInstructor());
                    this.vista.txtMonitor.setText(objEstudiante.getNombreMonitor());
                }
            }
        }

        //Crear estudiante
        if (e.getSource() == this.vista.btnCrear) {
            vista.txtId.setEditable(true);
            int id = Integer.parseInt(this.vista.txtId.getText());
            String nombre = this.vista.txtNombre.getText();
            String direccion = this.vista.txtDireccion.getText();
            String fechadeNacimiento = this.vista.txtFechadeNacimiento.getText();
            String telefono = this.vista.txtTelefono.getText();
            String correo = this.vista.txtCorreo.getText();
            if (camposTextoVacios()) {
                this.vista.error("TODOS LOS CAMPOS DEBEN ESTAR LLENOS");
            } else {
                // Obtener el ID del instructor seleccionado
                int instructorId = obtenerIdInstructor((String) this.vista.comboxInstructor.getSelectedItem());
                String nombreInstructor = (String) vista.comboxInstructor.getSelectedItem();
                // Verificar si el nombre ya está en el ComboBox
                if (!nombreExistente(nombre) && !idExistente(id)) {
                    if (obtenerObjInstructor(nombreInstructor)==null){
                        System.out.print("Intructor no encontrado");
                    }else{
                        objInstructor = obtenerObjInstructor(nombreInstructor);
                        int materiaId = objInstructor.getMateriaId();
                         // El nombre no existe en el ComboBox, proceder con la inserción
                        EstudianteVO nuevoEstudiante = new EstudianteVO(id, instructorId, materiaId, nombre, direccion, fechadeNacimiento, telefono, correo);
                        this.miEstudianteDAO.insertarDatos(nuevoEstudiante);
                        this.vista.msg("El instructor fue agregado con exito");
                        this.llenarComboboxEstudiante();
                        llenarComboboxInstructor();
                        vista.limpiar();
                    }
                   
                } else {
                    this.vista.error("Ya existe el Instructor " + nombre + " con ID: " + id);
                }
            }
        }

        //Modificar Estudiante
        if (e.getSource() == this.vista.btnModificar) {
            listaEstudiantes = miEstudianteDAO.listaDeEstudiantes();
            String nombre = (String) this.vista.comboxEstudiantes.getSelectedItem();
            if (vista.txtNombre.getText().isEmpty() || vista.txtDireccion.getText().isEmpty() || vista.txtCorreo.getText().isEmpty() || vista.txtTelefono.getText().isEmpty()) {
                vista.error("NO SE PERMITEN ESPACIOS VACIOS");
            } else {
                for (EstudianteVO objEstudiante : miEstudianteDAO.listaDeEstudiantes()) {
                    if (objEstudiante.getNombre().equals(nombre)) {
                        objEstudiante.setNombre(this.vista.txtNombre.getText());
                        objEstudiante.setDireccion(this.vista.txtDireccion.getText());
                        objEstudiante.setFechaNacimiento(this.vista.txtFechadeNacimiento.getText());
                        objEstudiante.setTelefono(this.vista.txtTelefono.getText());
                        objEstudiante.setCorreo(this.vista.txtCorreo.getText());
                        this.miEstudianteDAO.actualizarDatos(objEstudiante);
                        this.vista.msg("INSTRUCTOR MODIFICADO");
                        this.vista.limpiar();
                        llenarComboboxEstudiante();
                        break;
                    }
                }
            }
        }

        //Modificar Instructor
        if (e.getSource() == this.vista.btnSeleccionarInstructor) {
            listaEstudiantes = miEstudianteDAO.listaDeEstudiantes();
            String Instructor = (String) this.vista.comboxInstructor.getSelectedItem();
            if ("".equals((String) this.vista.comboxEstudiantes.getSelectedItem())) {
                this.vista.error("Seleccione un estudiante primero");
            } else {
                String nombre = (String) this.vista.comboxEstudiantes.getSelectedItem();
                for (EstudianteVO objEstudiante : miEstudianteDAO.listaDeEstudiantes()) {
                    if (objEstudiante.getNombre().equals(nombre)) {
                        for (InstructorVO objInstructor : miInstructorDAO.listaDeInstructores()) {
                            if (objInstructor.getNombre().equals(Instructor)) {
                                int insTemp = objInstructor.getInstructorId();
                                objEstudiante.setInstructorId(insTemp);
                                this.miEstudianteDAO.actualizarDatos(objEstudiante);
                                this.vista.msg("La EL instructor ha sido actualizado");
                            }
                        }
                    }
                }
            }
        }

        //Eliminar
        if (e.getSource() == this.vista.btnEliminar) {
            vista.txtId.setEditable(true);
            listaEstudiantes = miEstudianteDAO.listaDeEstudiantes();
            String nombre = (String) this.vista.comboxEstudiantes.getSelectedItem();
            for (EstudianteVO objEstudiante : miEstudianteDAO.listaDeEstudiantes()) {
                if (objEstudiante.getNombre().equals(nombre)) {
                    int Id = objEstudiante.getEstudianteId();
                    this.miEstudianteDAO.eliminarEstudiante(Id);
                    this.vista.msg("Estudiante Eliminado");
                    this.vista.limpiar();
                    llenarComboboxEstudiante();
                    break;
                }
            }
        }

        //Lista
        if (e.getSource() == this.vista.btnLista) {
            this.vistaTabla.mostrarVentana(this.miEstudianteDAO.cargarDatosTabla(), "Estudiantes");
        }
    }
//Fin de la clase
}
