package Control.Gestores;

import Vista.VistaBienvenida;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GestorBienvenida implements ActionListener {

    private VistaBienvenida vista;
    private GestorInstructor gestorInstructor = new GestorInstructor();
    private GestorMonitor gestorMonitor = new GestorMonitor();
    private GestorEstudiante gestorEstudiante = new GestorEstudiante();
    private GestorMateria gestorMateria = new GestorMateria();
    
    public GestorBienvenida() {
        this.vista = new VistaBienvenida();
        this.vista.btnInstructor.addActionListener(this);
        this.vista.btnMonitor.addActionListener(this);
        this.vista.btnEstudiante.addActionListener(this);
        this.vista.btnMateria.addActionListener(this);
    }

    public void iniciar() {
        // Centra la vistaBienvenida en el centro de la pantalla
        this.vista.setLocationRelativeTo(null);

        this.vista.setResizable(false);
        // Hace visible la vistaBienvenida
        this.vista.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == this.vista.btnInstructor) {
            this.vista.setVisible(false);
            gestorInstructor.iniciar(this);
        }
        if (e.getSource() == this.vista.btnMonitor) {
            this.vista.setVisible(false);
            gestorMonitor.iniciar(this);
        }
        if (e.getSource() ==this.vista.btnEstudiante){
            this.vista.setVisible(false);
            gestorEstudiante.iniciar(this);
        }
        if (e.getSource() ==this.vista.btnMateria){
            this.vista.setVisible(false);
            gestorMateria.iniciar(this);
        }        
    }
}