package Control.DAO;

//Importar packages
import Modelo.EstudianteVO;
import Modelo.Conexion.Conexion;
import Vista.VistaEstudiante;
// PreparedStatement permite ejecutar consultas SQL precompiladas, mejorando la seguridad y rendimiento.
import com.mysql.jdbc.PreparedStatement;
// Estas clases son esenciales para interactuar con bases de datos mediante JDBC.
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
// ArrayList es una colección dinámica que facilita el manejo de conjuntos de datos.
import java.util.ArrayList;
// DefaultTableModel es una implementación de TableModel para gestionar datos tabulares en componentes Swing.
import javax.swing.table.DefaultTableModel;

public class EstudianteDAO {

    // Declaración de una variable de tipo Connection para gestionar la conexión a la base de datos.
    private Connection con;
    // Declaración de una variable de tipo Statement para ejecutar consultas SQL.
    private Statement st;
    // Declaración de una variable de tipo ResultSet para almacenar los resultados de consultas SQL.
    private ResultSet rs;
    // Declaración de una variable de tipo VistaMenu, para manejar la interfaz gráfica del menú.
    private VistaEstudiante vista = new VistaEstudiante();

    public EstudianteDAO() {
        // Inicializa las variables de conexión y resultados a null
        this.con = null;
        this.st = null;
        this.rs = null;
    }

    public ArrayList<EstudianteVO> listaDeEstudiantes() {
        ArrayList<EstudianteVO> listaEstudiantes = new ArrayList<>();
        String consulta = "SELECT e.*, i.nombre as nombreInstructor, m.nombre as nombreMateria, mo.nombre as nombreMonitor "
                + "FROM estudiante e "
                + "LEFT JOIN instructor i ON e.instructorId = i.instructorId "
                + "LEFT JOIN materia m ON i.materiaId = m.materiaId "
                + "LEFT JOIN monitor mo ON i.monitorId = mo.monitorId";
        Connection con = null;
        Statement st = null;
        ResultSet rs = null;
        try {
            con = Conexion.getConexion();
            st = con.createStatement();
            rs = st.executeQuery(consulta);
            while (rs.next()) {
                EstudianteVO estudiante = new EstudianteVO(
                        rs.getInt("estudianteId"),
                        rs.getInt("instructorId"),
                        rs.getInt("materiaId"),
                        rs.getString("nombre"),
                        rs.getString("telefono"),
                        rs.getString("direccion"),
                        rs.getString("fecha_nacimiento"),
                        rs.getString("correo"),
                        rs.getString("nombreInstructor"),
                        rs.getString("nombreMateria"),
                        rs.getString("nombreMonitor")
                );
                listaEstudiantes.add(estudiante);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            if (vista != null) {
                vista.error("Error en la consulta de la base de datos");
            }
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (st != null) {
                    st.close();
                }
                if (con != null) {
                    Conexion.desconectar();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        return listaEstudiantes;
    }

    public void actualizarDatos(EstudianteVO objEstudiante) {
        // Consulta de actualización con PreparedStatement
        String modificacion = "UPDATE `estudiante` SET `estudianteId`=?, `instructorId`=?, `materiaId`=?, `nombre`=?, `direccion`=? , `fecha_nacimiento`=?, `telefono`=?, `correo`=? WHERE `estudianteId`=?";
        try {
            // Obtiene una conexión a la base de datos
            con = Conexion.getConexion();
            // Crea una consulta preparada
            PreparedStatement pst = (PreparedStatement) con.prepareStatement(modificacion);
            // Establece los parámetros de la consulta
            pst.setInt(1, objEstudiante.getEstudianteId());
            pst.setInt(2, objEstudiante.getInstructorId());
            pst.setInt(3, objEstudiante.getMateriaId());
            pst.setString(4, objEstudiante.getNombre());
            pst.setString(5, objEstudiante.getDireccion());
            pst.setString(6, objEstudiante.getFechaNacimiento());
            pst.setString(7, objEstudiante.getTelefono());
            pst.setString(8, objEstudiante.getCorreo());
            pst.setInt(9, objEstudiante.getEstudianteId());// Este último ? es para el WHERE
            // Ejecuta la consulta de actualización
            pst.executeUpdate();
            // Cierra la declaración y desconecta de la base de datos
            pst.close();
            Conexion.desconectar();
        } catch (SQLException ex) {
            // Imprime la traza de la excepción en caso de error
            ex.printStackTrace();
            // Manejo de excepciones en caso de error, mostrando un mensaje en la interfaz.
            vista.error("Ha ocurrido un error inesperado, No pudo ser modificado");
        }
    }

    public void insertarDatos(EstudianteVO objEstudiante) {
        try {
            // Obtiene una conexión a la base de datos
            con = Conexion.getConexion();
            // Consulta de inserción con PreparedStatement
            String insercion = "INSERT INTO estudiante VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            // Crea una consulta preparada
            PreparedStatement pst = (PreparedStatement) con.prepareStatement(insercion);

            // Establece los parámetros de la consulta
            pst.setInt(1, objEstudiante.getEstudianteId());
            pst.setInt(2, objEstudiante.getInstructorId());
            pst.setInt(3, objEstudiante.getMateriaId());
            pst.setString(4, objEstudiante.getNombre());
            pst.setString(5, objEstudiante.getDireccion());
            pst.setString(6, objEstudiante.getFechaNacimiento());
            pst.setString(7, objEstudiante.getTelefono());
            pst.setString(8, objEstudiante.getCorreo());

            // Ejecuta la consulta de inserción
            pst.executeUpdate();

            // Cierra la declaración y desconecta de la base de datos
            pst.close();
            Conexion.desconectar();

        } catch (SQLException ex) {
            // Manejo de excepciones en caso de error
            ex.printStackTrace();
            vista.error("Ha ocurrido un error inesperado, No pudo ser creado");
        }
    }

    public void eliminarEstudiante(int estudianteId) {
        String consulta = "DELETE FROM estudiante where estudianteId='" + estudianteId + "'";
        try {
            con = Conexion.getConexion();
            st = con.createStatement();
            st.executeUpdate(consulta);
            st.close();
            Conexion.desconectar();
        } catch (SQLException ex) {
            ex.printStackTrace();
            this.vista.error("Ha ocurrido un error inesperado, no pudo ser eliminado");
        }
    }

    // Método para cargar datos desde la base de datos y construir un DefaultTableModel para una tabla Swing.
    public DefaultTableModel cargarDatosTabla() {
        try {
            // Consulta SQL para obtener los datos de la tabla cliente.
            String consulta = "SELECT * FROM estudiante";
            con = Conexion.getConexion();
            st = con.createStatement();
            rs = st.executeQuery(consulta);
            // Crear un modelo de tabla para contener los datos.
            DefaultTableModel modelo = new DefaultTableModel();
            // Obtener los nombres de las columnas de metadatos y agregarlos al modelo.
            int columnCount = rs.getMetaData().getColumnCount();
            for (int i = 1; i <= columnCount; i++) {
                modelo.addColumn(rs.getMetaData().getColumnName(i));
            }
            // Rellenar el modelo de tabla con los datos obtenidos de la base de datos.
            while (rs.next()) {
                Object[] fila = new Object[columnCount];
                for (int i = 1; i <= columnCount; i++) {
                    fila[i - 1] = rs.getObject(i);
                }
                modelo.addRow(fila);
            }
            // Agregar una fila adicional al principio con los nombres de las columnas.
            Object[] nombresColumnas = new Object[columnCount];
            for (int i = 1; i <= columnCount; i++) {
                nombresColumnas[i - 1] = modelo.getColumnName(i - 1);
            }
            modelo.insertRow(0, nombresColumnas);
            // Devolver el modelo de tabla creado.
            return modelo;

        } catch (SQLException e) {
            // Imprime la traza de la excepción en caso de error.
            e.printStackTrace();
        }
        // En caso de error, retorna null.
        vista.error("Ha ocurrido un error inesperado creando la lista de estudiantes");
        return null;
    }
//Fin de la clase
}
