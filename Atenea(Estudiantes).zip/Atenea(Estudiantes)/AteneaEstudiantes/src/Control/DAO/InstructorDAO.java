package Control.DAO;

import Modelo.InstructorVO;
import Modelo.Conexion.Conexion;
import Vista.VistaInstructor;
// PreparedStatement permite ejecutar consultas SQL precompiladas, mejorando la seguridad y rendimiento.
import com.mysql.jdbc.PreparedStatement;
// Estas clases son esenciales para interactuar con bases de datos mediante JDBC.
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
// ArrayList es una colección dinámica que facilita el manejo de conjuntos de datos.
import java.util.ArrayList;
// DefaultTableModel es una implementación de TableModel para gestionar datos tabulares en componentes Swing.
import javax.swing.table.DefaultTableModel;

public class InstructorDAO {

    // Declaración de una variable de tipo Connection para gestionar la conexión a la base de datos.
    private Connection con;
    // Declaración de una variable de tipo Statement para ejecutar consultas SQL.
    private Statement st;
    // Declaración de una variable de tipo ResultSet para almacenar los resultados de consultas SQL.
    private ResultSet rs;
    // Declaración de una variable de tipo VistaMenu, para manejar la interfaz gráfica del menú.
    private VistaInstructor vista = new VistaInstructor();

    public InstructorDAO() {
        // Inicializa las variables de conexión y resultados a null
        this.con = null;
        this.st = null;
        this.rs = null;
    }

// Método que retorna una lista de objetos InstructorVO, obtenidos desde la base de datos.
    public ArrayList<InstructorVO> listaDeInstructores() {
        ArrayList<InstructorVO> listaInstructores = new ArrayList<>();
        // Consulta SQL extendida para incluir nombres de materia y monitor.
        String consulta = "SELECT i.*, m.nombre as nombreMateria, mo.nombre as nombreMonitor "
                + "FROM instructor i "
                + "LEFT JOIN materia m ON i.materiaId = m.materiaId "
                + "LEFT JOIN monitor mo ON i.monitorId = mo.monitorId";
        try {
            con = Conexion.getConexion();
            st = con.createStatement();
            rs = st.executeQuery(consulta);
            while (rs.next()) {
                listaInstructores.add(new InstructorVO(
                        rs.getInt("instructorId"),
                        rs.getInt("monitorId"),
                        rs.getInt("materiaId"),
                        rs.getString("nombre"),
                        rs.getString("direccion"),
                        rs.getString("fecha_nacimiento"),
                        rs.getString("telefono"),
                        rs.getString("correo"),
                        rs.getString("nombreMateria"),
                        rs.getString("nombreMonitor")
                ));
            }
            st.close();
            Conexion.desconectar();
        } catch (SQLException e) {
            e.printStackTrace();
            vista.error("Ocurrio un error inesperado en la consulta con la Base de Datos");
        }
        return listaInstructores;
    }

    // Método para actualizar datos de un cliente en la base de datos.
    public void actualizarDatos(InstructorVO objInstructor) {
        String modificacion = "UPDATE instructor SET monitorId=?, materiaId=?, nombre=?, direccion=?, fecha_nacimiento=?, telefono=?, correo=? WHERE instructorId=?";
        try {
            con = Conexion.getConexion();
            PreparedStatement pst = (PreparedStatement) con.prepareStatement(modificacion);
            pst.setInt(1, objInstructor.getMonitorId());
            pst.setInt(2, objInstructor.getMateriaId());
            pst.setString(3, objInstructor.getNombre());
            pst.setString(4, objInstructor.getDireccion());
            pst.setString(5, objInstructor.getFechaNacimiento());
            pst.setString(6, objInstructor.getTelefono());
            pst.setString(7, objInstructor.getCorreo());
            pst.setInt(8, objInstructor.getInstructorId());
            pst.executeUpdate();
            pst.close();
            Conexion.desconectar();
        } catch (SQLException ex) {
            ex.printStackTrace();
            vista.error("Ha ocurrido un error inesperado, no se han actualizado los datos");
        }
    }

    public void insertarDatos(InstructorVO objInstructor) {
        String insercion = "INSERT INTO instructor VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try {
            con = Conexion.getConexion();
            PreparedStatement pst = (PreparedStatement) con.prepareStatement(insercion);
            pst.setInt(1, objInstructor.getInstructorId());
            pst.setInt(2, objInstructor.getMonitorId());
            pst.setInt(3, objInstructor.getMateriaId());
            pst.setString(4, objInstructor.getNombre());
            pst.setString(5, objInstructor.getDireccion());
            pst.setString(6, objInstructor.getFechaNacimiento());
            pst.setString(7, objInstructor.getTelefono());
            pst.setString(8, objInstructor.getCorreo());
            pst.executeUpdate();
            pst.close();
            Conexion.desconectar();
        } catch (SQLException ex) {
            ex.printStackTrace();
            vista.error("Ha ocurrido un error inesperado, no pudo ser creado");
        }
    }

    public void eliminarInstructor(int instructorId) {
        String consulta = "DELETE FROM instructor where instructorId='" + instructorId + "'";
        try {
            con = Conexion.getConexion();
            st = con.createStatement();
            st.executeUpdate(consulta);
            st.close();
            Conexion.desconectar();
        } catch (SQLException ex) {
            ex.printStackTrace();
            this.vista.error("Ha ocurrido un error inesperado, no pudo ser eliminado");
        }
    }

    // Método para cargar datos desde la base de datos y construir un DefaultTableModel para una tabla Swing.
    public DefaultTableModel cargarDatosTabla() {
        try {
            // Consulta SQL para obtener los datos de la tabla cliente.
            String consulta = "SELECT * FROM instructor";
            con = Conexion.getConexion();
            st = con.createStatement();
            rs = st.executeQuery(consulta);
            // Crear un modelo de tabla para contener los datos.
            DefaultTableModel modelo = new DefaultTableModel();
            // Obtener los nombres de las columnas de metadatos y agregarlos al modelo.
            int columnCount = rs.getMetaData().getColumnCount();
            for (int i = 1; i <= columnCount; i++) {
                modelo.addColumn(rs.getMetaData().getColumnName(i));
            }
            // Rellenar el modelo de tabla con los datos obtenidos de la base de datos.
            while (rs.next()) {
                Object[] fila = new Object[columnCount];
                for (int i = 1; i <= columnCount; i++) {
                    fila[i - 1] = rs.getObject(i);
                }
                modelo.addRow(fila);
            }
            // Agregar una fila adicional al principio con los nombres de las columnas.
            Object[] nombresColumnas = new Object[columnCount];
            for (int i = 1; i <= columnCount; i++) {
                nombresColumnas[i - 1] = modelo.getColumnName(i - 1);
            }
            modelo.insertRow(0, nombresColumnas);
            // Devolver el modelo de tabla creado.
            return modelo;

        } catch (SQLException e) {
            // Imprime la traza de la excepción en caso de error.
            e.printStackTrace();
        }
        // En caso de error, retorna null.
        return null;
    }
}
