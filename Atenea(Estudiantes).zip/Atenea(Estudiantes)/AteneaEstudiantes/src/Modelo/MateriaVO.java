package Modelo;

public class MateriaVO {

    //Atributo id referencia materia
    int materiaId;
    
    //Atributos de materia 
    String nombre, descripcion;
    
    //Constructor referencia para lectura, insercion, modificacion y eliminacion de materias en la db
    public MateriaVO(int materiaId, String nombre, String descripcion) {
        this.materiaId = materiaId;
        this.nombre = nombre;
        this.descripcion = descripcion;
    }

    //Metodos getters y setters
    
    public MateriaVO() {
    }

    public int getMateriaId() {
        return materiaId;
    }

    public void setMateriaId(int materiaId) {
        this.materiaId = materiaId;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
}