package Modelo;

public class InstructorVO {
    
    //Atributos id correspondientes a instructor
    int instructorId, monitorId, materiaId;
    
    //Atributos de instructor
    String nombre, direccion, fechaNacimiento, telefono, correo, nombreMateria, nombreMonitor;

    //Constructor referencia para lectura, modificaciones y eliminaciones de un instructor
    public InstructorVO(int instructorId, int monitorId, int materiaId, String nombre, String direccion, String fechaNacimiento, String telefono, String correo, String nombreMateria, String nombreMonitor) {
        this.instructorId = instructorId;
        this.monitorId = monitorId;
        this.materiaId = materiaId;
        this.nombre = nombre;
        this.direccion = direccion;
        this.fechaNacimiento = fechaNacimiento;
        this.telefono = telefono;
        this.correo = correo;
        this.nombreMateria = nombreMateria;
        this.nombreMonitor = nombreMonitor;
    }

    //Constructor de referencia para inserciones
    public InstructorVO(int instructorId, int monitorId, int materiaId, String nombre, String direccion, String fechaNacimiento, String telefono, String correo) {
        this.instructorId = instructorId;
        this.monitorId = monitorId;
        this.materiaId = materiaId;
        this.nombre = nombre;
        this.direccion = direccion;
        this.fechaNacimiento = fechaNacimiento;
        this.telefono = telefono;
        this.correo = correo;
    }
    
    //Metodos getters y setters
    
    public InstructorVO() {
    }

    public int getInstructorId() {
        return instructorId;
    }

    public void setInstructorId(int instructorId) {
        this.instructorId = instructorId;
    }

    public int getMonitorId() {
        return monitorId;
    }

    public void setMonitorId(int monitorId) {
        this.monitorId = monitorId;
    }

    public int getMateriaId() {
        return materiaId;
    }

    public void setMateriaId(int materiaId) {
        this.materiaId = materiaId;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(String fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getNombreMateria() {
        return nombreMateria;
    }

    public void setNombreMateria(String nombreMateria) {
        this.nombreMateria = nombreMateria;
    }

    public String getNombreMonitor() {
        return nombreMonitor;
    }

    public void setNombreMonitor(String nombreMonitor) {
        this.nombreMonitor = nombreMonitor;
    }

}