package Modelo;

public class EstudianteVO {
    
    //Atributos id correspondiente a estudiante
    int estudianteId, instructorId, materiaId;
    
    //Atributos de estudiante
    String nombre, direccion, fechaNacimiento, telefono, correo, nombreMateria, nombreInstructor, nombreMonitor;

    
    //Constructor de referencia para lectura, modificaciones y eliminaciones
    public EstudianteVO(int estudianteId, int instructorId, int materiaId, String nombre, String direccion, String fechaNacimiento, String telefono, String correo, String nombreMateria, String nombreInstructor, String nombreMonitor) {
        this.estudianteId = estudianteId;
        this.instructorId = instructorId;
        this.materiaId = materiaId;
        this.nombre = nombre;
        this.direccion = direccion;
        this.fechaNacimiento = fechaNacimiento;
        this.telefono = telefono;
        this.correo = correo;
        this.nombreMateria = nombreMateria;
        this.nombreInstructor = nombreInstructor;
        this.nombreMonitor = nombreMonitor;
    }
    
    //Constructor de referencia para inserciones
    public EstudianteVO(int estudianteId, int instructorId, int materiaId, String nombre, String direccion, String fechaNacimiento, String telefono, String correo) {
        this.estudianteId = estudianteId;
        this.instructorId = instructorId;
        this.materiaId = materiaId;
        this.nombre = nombre;
        this.direccion = direccion;
        this.fechaNacimiento = fechaNacimiento;
        this.telefono = telefono;
        this.correo = correo;
    }

    
    //Metodos getter y setters
    
    public EstudianteVO() {
    }

    public int getEstudianteId() {
        return estudianteId;
    }

    public void setEstudianteId(int estudianteId) {
        this.estudianteId = estudianteId;
    }

    public int getInstructorId() {
        return instructorId;
    }

    public void setInstructorId(int instructorId) {
        this.instructorId = instructorId;
    }

    public int getMateriaId() {
        return materiaId;
    }

    public void setMateriaId(int materiaId) {
        this.materiaId = materiaId;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(String fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getNombreMateria() {
        return nombreMateria;
    }

    public void setNombreMateria(String nombreMateria) {
        this.nombreMateria = nombreMateria;
    }

    public String getNombreInstructor() {
        return nombreInstructor;
    }

    public void setNombreInstructor(String nombreInstructor) {
        this.nombreInstructor = nombreInstructor;
    }

    public String getNombreMonitor() {
        return nombreMonitor;
    }

    public void setNombreMonitor(String nombreMonitor) {
        this.nombreMonitor = nombreMonitor;
    }
}