package Modelo;
public class MonitorVO {
    
    //Atributo id referencia de monitor
    int monitorId;
    
    //Atributos de monitor
    String nombre, direccion, fechaNacimiento, telefono, correo;

    //Constructor de referencia para mostrar, modificar, insertar y eliminar un monitor
    public MonitorVO(int monitorId, String nombre, String direccion, String fechaNacimiento, String telefono, String correo) {
        this.monitorId = monitorId;
        this.nombre = nombre;
        this.direccion = direccion;
        this.fechaNacimiento = fechaNacimiento;
        this.telefono = telefono;
        this.correo = correo;
    }

    
    //Metodos getters y setters
    
    public MonitorVO() {
    }

    public int getMonitorId() {
        return monitorId;
    }

    public void setMonitorId(int monitorId) {
        this.monitorId = monitorId;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(String fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }
    
    

}
