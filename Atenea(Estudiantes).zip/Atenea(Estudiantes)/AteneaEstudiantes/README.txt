Proyecto CRUD desarrollado conbase de datos en XAMPP con Apache y MySQL, gestionado con PhpMyAdmin.
Es necesario crear la tabla ´atenea´ antes de ejecutar el script de la db.
